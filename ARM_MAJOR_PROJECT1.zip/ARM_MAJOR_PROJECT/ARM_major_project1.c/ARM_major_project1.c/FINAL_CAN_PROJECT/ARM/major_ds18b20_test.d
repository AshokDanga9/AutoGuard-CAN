major_ds18b20_test.o: Major_ds18b20_test.c
major_ds18b20_test.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.h
major_ds18b20_test.o: delay.h
major_ds18b20_test.o: Major_dsb18b20.h
major_ds18b20_test.o: types.h
