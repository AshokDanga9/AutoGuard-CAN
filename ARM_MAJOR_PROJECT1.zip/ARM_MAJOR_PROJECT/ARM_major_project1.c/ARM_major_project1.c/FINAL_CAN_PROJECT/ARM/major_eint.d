major_eint.o: Major_EINT.c
major_eint.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.h
major_eint.o: delay.h
major_eint.o: Major_Can.h
major_eint.o: types.h
major_eint.o: types.h
