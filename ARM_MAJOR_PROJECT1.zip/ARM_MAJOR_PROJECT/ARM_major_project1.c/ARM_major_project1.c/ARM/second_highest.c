#include<LPC21xx.h>
//#inlcude "rand.h"
int high( int sum)
{
	int temp,digit,h=0,sh=0;
 temp=sum;
        while(temp)
        {
                digit=temp%10;
                if(digit>h)
                {
                        sh=h;
                        h=digit;
                }
                else{
                        if(sh<digit && digit!=h)
                        sh=digit;
        }
                temp=temp/10;
        }
		return sh;
}
