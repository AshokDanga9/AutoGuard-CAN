//DS18B20 TEMPRATURE SENSOR
#include <LPC22xx.H>
#include"delay.h"
#include"types.h"
#include"Major_dsb18b20.h"
//#define DP  15
#define Dat 1<<15
#define Rdst (IOPIN0&(1<<15)) // Read_status
u8 ResetDs18b20(void)

{
unsigned int presence;
IODIR0 |=Dat;
IOSET0 =Dat;
IOCLR0=Dat;
delay_us(480);
IOSET0 =Dat;
IODIR0 &=~Dat;
delay_us(60);
presence=Rdst;
//presence=IOPIN0 & Dat;
delay_us(420);
return (presence ? 0 : 1);
 }
 u8 ReadBit(void)
 {
 	unsigned int Bit;
	IODIR0|=Dat;
	//IOPIN0 &=~(Dat);
	IOCLR0 = Dat;
	delay_us(2);
	IOSET0 = Dat;
	IODIR0 &=~(Dat);
	delay_us(11);
	Bit=Rdst;
	delay_us(50);
	//IODIR0 |= Dat;
	if(Bit)
	{
		return 1;
	}
 	else
	{
		return 0;
	}
 }
 void WriteBit(u8 Databit)
 {
    IODIR0|=Dat;
 	IOCLR0 &=Dat;
	delay_us(2);
	if(Databit)
		IOSET0|=Dat;
	delay_us(60);
	IOSET0 = Dat;
	//delay_us(1);
  }
 u8 ReadByte(void)
  {
  	unsigned char i;
	unsigned char DatIn=0;
	for(i=0;i<8;i++)
	{
		if(ReadBit())
		  DatIn |=(1<<i);	
	}
  	return (DatIn);
  }
void WriteByte(u8 DatOut)
{
	u8 i;
	for(i=0;i<8;i++)
	{
		WriteBit(DatOut&0x1);
		DatOut>>=1;
		//delay_us(1);
	}
	//delay_us(100);
}
int ReadTemp(void)
{
	u8 lsb,msb;
	int temp;
	ResetDs18b20();
	WriteByte(0xcc);
	WriteByte(0x44);
	delay_ms(750);
	ResetDs18b20();
	WriteByte(0xcc);
	WriteByte(0xBE);
	lsb=ReadByte();
	msb=ReadByte();
	temp=(msb<<8)|lsb;
	return (temp);
}
