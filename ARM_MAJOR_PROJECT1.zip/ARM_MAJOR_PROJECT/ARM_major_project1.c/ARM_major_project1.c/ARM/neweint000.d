neweint000.o: neweint000.c
neweint000.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.h
neweint000.o: delay.h
neweint000.o: Major_Can.h
neweint000.o: types.h
neweint000.o: types.h
neweint000.o: Major_candefines.h
