#include<LPC21xx.h>
#include"macros.h"
#include"ispalindrome.h"
#include"delay.h"
int i;
int main()
{
//int i;
WRITEBYTE(IODIR0,8,0XFF);//PORT0.8 TO PORT0.15
WRITEBYTE(IODIR0,0,0XFF);//PORT0.8 TO PORT0.15

//WRITENIBBLE(IOPIN0,8,0x0f);
for(i=100;i<=200;i++)
{
if(ispalindrome(i))
{
/*IOCLR0=0XFF<<8;
IOSET0=(i<<8)^(0XF0<<8);
delay_ms(500);*/
//IOPIN0^=(IOPIN0&~(0XFF<<8))|((IOPIN0>>8)&i<<8)^0xF0<<8;
IOPIN0=i<<8;
IOPIN0|=10<<0;
}
}                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           while(1);
}
