ass2.o: ass2.c
ass2.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.h
ass2.o: delay.h
ass2.o: macros.h
