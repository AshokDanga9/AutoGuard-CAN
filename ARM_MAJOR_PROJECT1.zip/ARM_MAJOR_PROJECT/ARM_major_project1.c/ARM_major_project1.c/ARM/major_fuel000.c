#include<lpc21xx.h>

#include "major_adc.h"

#include "major_adc_defines.h"

#include "major_lcd.h"

#include "delay.h"

int main()

{
	int temp;
	float Adcval;

	float eAR;

	initadc();

	InitLCD();
			   	//display_lcd('A');
	while(1)

	{


		Read_ADC(u32 chNo,f32 *eAR ,u32 *adcDVal);

		temp=eAR*100;
		CmdLCD(0x01);
		CmdLCD(0x80);
		StrLCD("FUEL: ");
		IntLCD(temp);
		delay_ms(10);
		//display_lcd('A');
	}  
}