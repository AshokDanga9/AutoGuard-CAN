sample1.o: sample1.c
sample1.o: C:\KeilARM\ARM\INC\Philips\lpc21xx.h
