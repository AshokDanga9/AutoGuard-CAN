#include <LPC21xx.H>
#include"keypad_fun_define.h"
//#include"typedef.h"
#include "lut.h"
u8 LLUT[][4]={{'1','2','3','+'},{'4','5','6','-'},{'7','8','9','*'},{'0','%','/','='}};
s8 r_val=0,c_val=0;
void keypadInt(void)	 // Intilization of keypad!
{
	IODIR0|=((1<<r0)|(1<<r1)|(1<<r2)|(1<<r3));  // setting to o/p direction
	IOCLR0=((1<<r0)|(1<<r1)|(1<<r2)|(1<<r3));	  // intially rows should be zeros
}  
s8 KeyVal(void)
 {
 		char r_val=0,c_val=0;
 	IOCLR0=1<<r0;
	IOSET0=((1<<r1)|(1<<r2)|(1<<r3));
	if((((IOPIN0>>c0)&0X0F) != 0X0F))
	{		r_val=0;
		goto col_check;
	}
	IOCLR0=1<<r1;
	IOSET0=((1<<r0)|(1<<r2)|(1<<r3));
	 if((((IOPIN0>>c0)&0X0F) != 0X0F))
	{
		r_val=1;
		goto col_check;
	}
	IOCLR0=1<<r2;
	IOSET0=((1<<r0)|(1<<r1)|(1<<r3));
	 if((((IOPIN0>>c0)&0X0F) != 0X0F))
	{ 	
		r_val=2;
		goto col_check;
	}
	IOCLR0=1<<r3;
	IOSET0=((1<<r0)|(1<<r1)|(1<<r2));
	if((((IOPIN0>>c0)&0X0F) != 0X0F))
	{
		r_val=3;
		//goto col_check;
	}
col_check:
	if(((IOPIN0>>c0)&1) == 0)
	{
		c_val=0;
	}
	else if(((IOPIN0>>c1)&1)== 0)
	{
		c_val=1;
	}
		
	else if(((IOPIN0>>c2)&1) == 0)
	{
		c_val=2;
	}
	else  
	{
		c_val=3;
	}
	IOCLR0=((1<<r0)|(1<<r1)|(1<<r2)|(1<<r3));
	return (LLUT[r_val][c_val]);
}
/*void edit(void)
{
			  
 while(1)
        {
        if(((IOPIN0>>SW)&1)==0)
        {
           while(((IOPIN0>>SW)&1)==0);   // wait for release

                while(1)   // MENU LOOP
                 {
                 CmdLCD(0x01);
                  CmdLCD(0x80);
                  Disp_menu();

                  key = KeyVal();   // read keypad key

                  }
				  }
}
} */