rtc.o: rtc.c
