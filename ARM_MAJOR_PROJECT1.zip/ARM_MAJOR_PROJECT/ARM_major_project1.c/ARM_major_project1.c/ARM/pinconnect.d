pinconnect.o: pinconnect.c
pinconnect.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.h
