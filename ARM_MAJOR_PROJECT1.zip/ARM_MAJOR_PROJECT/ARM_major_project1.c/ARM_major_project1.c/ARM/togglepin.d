togglepin.o: togglepin.c
togglepin.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.h
togglepin.o: pinconnectfunc.h
togglepin.o: macros.h
togglepin.o: delay.h
