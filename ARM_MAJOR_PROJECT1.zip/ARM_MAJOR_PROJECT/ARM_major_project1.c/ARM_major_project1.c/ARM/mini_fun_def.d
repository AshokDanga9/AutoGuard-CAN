mini_fun_def.o: mini_fun_def.c
mini_fun_def.o: C:\KeilARM\ARM\INC\Philips\LPC21XX.H
mini_fun_def.o: types.h
mini_fun_def.o: all_fun_decl.h
mini_fun_def.o: types.h
mini_fun_def.o: types.h
mini_fun_def.o: delay.h
mini_fun_def.o: macros.h
