first_fourr.o: first_fourr.c
first_fourr.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.h
first_fourr.o: delay.h
first_fourr.o: macros.h
