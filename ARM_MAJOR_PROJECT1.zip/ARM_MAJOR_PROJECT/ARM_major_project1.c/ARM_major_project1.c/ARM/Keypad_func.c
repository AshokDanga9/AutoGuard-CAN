#include<LPC21xx.h>
//#include"Keypad_funcdef.h"
#include"Keypad_fun_define.h"
#include"lut.h"
#include"LCD.h"
s8 R,C;
void Keyint(void)
{
	IODIR0|=((1<<R0)|(1<<R1)|(1<<R2)|(1<<R3));

	    //P0.15-P0.18 are for output functionality

		IOCLR0=((1<<R0)|(1<<R1)|(1<<R2)|(1<<R3));

		//Initializing rows to 0
	IOSET0=((1<<C0)|(1<<C1)|(1<<C2)|(1<<C3));
	//P0.19-P0.22 are set to 1 
	}
u8 colcheck(void)
{
  if(((IOPIN0>>19)&0x0f)==0x0f)// here pin status from from C0-C3 is checked 
  	return 1;
  else
  	return 0;
}
u8 Keyval(void)
{
 IOCLR0=1<<R0;
 IOSET0=(1<<R1)|(1<<R2)|(1<<R3);
 if(((IOPIN0>>C0)&15)!=15)
 {
   R=0;
   COLCHECK();
   	return (LUT[R][C]);
 }
		   IOCLR0=1<<R1;
		   IOSET0=(1<<R0)|(1<<R2)|(1<<R3);
		    if(((IOPIN0>>C0)&15)!=15)
		   {
		     R=1;
			 COLCHECK();
			 return (LUT[R][C]);
		   }

  			IOCLR0=1<<R2;
  			IOSET0=(1<<R0)|(1<<R1)|(1<<R3);
   			if(((IOPIN0>>C0)&15)!=15)
  			{
    			R=2;
	 			COLCHECK();
				return (LUT[R][C]);
			}
       		IOCLR0=1<<R3;
  			IOSET0=(1<<R1)|(1<<R2)|(1<<R0);
   			if(((IOPIN0>>C0)&15)!=15)
			 {
			    R=3;
			    COLCHECK();
				return (LUT[R][C]);
			 }
//return (LUT[R][C]);
    }
u8 COLCHECK(void)
{
	 if(((IOPIN0>>C0)&1)==0)
	 C=0;
	 else if(((IOPIN0>>C1)&1)==0)
	 C=1;
	 else if (((IOPIN0>>C2)&1)==0)
	 C=2;
	 else
	 C=3;
}



