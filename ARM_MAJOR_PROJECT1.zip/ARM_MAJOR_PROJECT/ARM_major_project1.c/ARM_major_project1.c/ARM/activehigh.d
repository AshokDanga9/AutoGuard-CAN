activehigh.o: activehigh.c
activehigh.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.h
activehigh.o: macros.h
activehigh.o: delay.h
