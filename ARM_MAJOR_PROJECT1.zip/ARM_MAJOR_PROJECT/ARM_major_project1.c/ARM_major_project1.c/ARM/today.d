today.o: today.c
today.o: C:\KeilARM\ARM\INC\Philips\lpc21xx.h
today.o: types.h
today.o: delay.h
today.o: Major_adc.h
today.o: types.h
today.o: lcd.h
today.o: types.h
