#include<LPC21xx.h>
int main()
{
	PINSEL0=(PINSEL0 & ~(3<<26))|(3<<26);
	while(1);
}
