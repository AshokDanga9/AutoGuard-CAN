#include"delay.h"

int main()

{

	delay_us(1);

	delay_ms(1);

	delay_s(1);

	

	while(1);//superloop architecture

}
