main_lcd.o: main_LCD.c
main_lcd.o: lcd.h
main_lcd.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.h
main_lcd.o: types.h
main_lcd.o: delay.h
main_lcd.o: macros.h
