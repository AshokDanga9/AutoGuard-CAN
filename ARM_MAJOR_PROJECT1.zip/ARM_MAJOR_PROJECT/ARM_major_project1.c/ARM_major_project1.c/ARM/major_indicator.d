major_indicator.o: Major_Indicator.c
major_indicator.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.H
major_indicator.o: Major_Can.h
major_indicator.o: types.h
major_indicator.o: types.h
major_indicator.o: delay.h
