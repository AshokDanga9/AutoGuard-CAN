major_adc_def.o: Major_adc_def.c
major_adc_def.o: C:\KeilARM\ARM\INC\Philips\lpc21xx.h
major_adc_def.o: types.h
major_adc_def.o: delay.h
