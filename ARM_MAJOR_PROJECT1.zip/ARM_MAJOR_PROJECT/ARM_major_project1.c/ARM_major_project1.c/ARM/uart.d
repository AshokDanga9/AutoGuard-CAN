uart.o: Uart.c
uart.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.h
uart.o: macros.h
uart.o: PinConnectFunc.h
uart.o: types.h
