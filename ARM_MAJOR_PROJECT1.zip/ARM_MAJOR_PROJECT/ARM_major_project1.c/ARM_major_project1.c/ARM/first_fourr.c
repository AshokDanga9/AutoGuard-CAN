#include<LPC21xx.h>
#include"delay.h"
#include"macros.h"
int main()
{
	int i;
		WRITEBYTE(IODIR0,8,0XFF);
	//	WRITENIBBLE(IOSET0,8,0X0F);
			while(1)
			{
			for(i=15;i>=12;i--)
				{
						IOSET0=1<<i;
						delay_ms(500);
						IOCLR0=1<<i;
						delay_ms(500);
				}
				}
				}