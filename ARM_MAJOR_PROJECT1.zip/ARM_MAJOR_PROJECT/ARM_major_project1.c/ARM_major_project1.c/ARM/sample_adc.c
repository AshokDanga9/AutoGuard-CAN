//adc.c
#include "types.h"
#include "delay.h"
#include <LPC21xx.h>
#include "Major_adc_defines.h"
/*
void Init_ADC(void)
{
	//clear all prev cfgs of p0.27-p0.30
	PINSEL1&=~(255<<22);
	//cfg p0.27-p0.30 as AIN0-AIN3 pins
	PINSEL1|=AIN0_PIN_0_27|AIN1_PIN_0_28|
	         AIN2_PIN_0_29|AIN3_PIN_0_30;
	//cfg ADCR
	ADCR|=(1<<PDN_BIT)|(CLKDIV<<CLKDIV_BITS);
}
*/

/*
void Init_ADC(u32 chNo)
{
	//clear prev cfgs of p0.27-p0.30
	PINSEL1&=~(AIN0_PIN_0_27|
	           AIN1_PIN_0_28|
	           AIN2_PIN_0_29|
	           AIN3_PIN_0_30);
	//PINSEL1&=~(chNo);
	//cfg req p0.27-p0.30 as AIN0-AIN3 pins
	PINSEL1|=chNo;
	//cfg ADCR
	ADCR|=(1<<PDN_BIT)|(CLKDIV<<CLKDIV_BITS);
}
*/



u32 adcChSel[4]={AIN0_PIN_0_27,
                 AIN1_PIN_0_28,
                 AIN2_PIN_0_29,
                 AIN3_PIN_0_30
                };

void Init_ADC(u32 chNo)
{
	//clear prev cfgs of p0.27-p0.30
	PINSEL1&=~(adcChSel[chNo]);
	//cfg req p0.27-p0.30 as AIN0-AIN3 pins
	PINSEL1|=adcChSel[chNo];
	//cfg ADCR
	ADCR|=(1<<PDN_BIT)|(CLKDIV<<CLKDIV_BITS);
}

void Read_ADC(u32 chNo,f32 *eAR,u32 *adcDVal)
{
	//clear any previous channel selection
	ADCR&=0xFFFFFF00;
	//update req chNo,& start conv
	ADCR|=((1<<ADC_CONV_START_BIT)|(1<<chNo));
	//wait for conv time
	delay_us(3);
	//check if conv completed successfully
	while(((ADDR>>DONE_BIT)&1)==0);
	//stop adc conversion
	ADCR&=~(1<<ADC_CONV_START_BIT);
	//read digital data
	*adcDVal=((ADDR>>DIGITAL_DATA_BITS)&1023);
	
	*eAR=*adcDVal * (3.3/1023);
}