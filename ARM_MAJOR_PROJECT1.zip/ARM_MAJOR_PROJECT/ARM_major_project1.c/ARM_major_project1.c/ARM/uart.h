#include"types.h"

void InitUART(void);

void UARTTxChar(s8);

void UARTTxStr(s8 *);

s8 UARTRxChar(void);