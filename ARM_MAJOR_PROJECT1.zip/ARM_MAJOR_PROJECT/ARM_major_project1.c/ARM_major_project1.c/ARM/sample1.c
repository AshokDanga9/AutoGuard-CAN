#include<lpc21xx.h>
int main(){
	while(1);
}