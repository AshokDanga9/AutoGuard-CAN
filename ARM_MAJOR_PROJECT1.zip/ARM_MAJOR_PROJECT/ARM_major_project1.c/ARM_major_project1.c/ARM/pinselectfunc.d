pinselectfunc.o: pinselectfunc.c
pinselectfunc.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.h
pinselectfunc.o: pinconnectfunc.h
