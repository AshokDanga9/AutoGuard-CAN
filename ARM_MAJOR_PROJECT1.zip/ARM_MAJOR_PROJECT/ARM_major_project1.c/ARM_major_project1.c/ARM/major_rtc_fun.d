major_rtc_fun.o: Major_rtc_fun.c
major_rtc_fun.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.H
major_rtc_fun.o: rtc_defines.h
major_rtc_fun.o: types.h
major_rtc_fun.o: lcd.h
major_rtc_fun.o: types.h
