#include<LPC21xx.h>
int ispalindrome(int i)
{
int j,rev=0,digit;
j=i;
while(j)
{
digit=j%10;
rev=rev*10+digit;
j=j/10;
}
if(i==rev)
{
return i;
}
else
{
return 0;
}
}