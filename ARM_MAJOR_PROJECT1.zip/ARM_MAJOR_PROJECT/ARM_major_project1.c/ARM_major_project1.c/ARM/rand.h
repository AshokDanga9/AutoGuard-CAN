int pand(int);
int high( int);
