#include<LPC21xx.h>

#include"PinConnectfunc.h"

#include"macros.h"

#define FN1 0

#define FN2 1

#define FN3 2

#define FN4 3


int main()

{
	cfgPinFunc(0,1,FN3);// to check if its sets given fn3.

	WRITEHWORD(PINSEL0,0,0);//P0.0-P0.7 Select GPIO

	cfgPinFunc(0,11,FN1);//P0.11 with fn1(GPIO) 

	cfgPinFunc(0,23,FN1);//P0.23 with fn1(GPIO)

	//IODIR0|=((1<<11)|(1<<23));

	SETBIT(IODIR0,11);

	SETBIT(IODIR0,23);

	

	while(1);

}
