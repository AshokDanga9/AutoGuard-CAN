#include<LPC21XX.h>
#include"types.h"
#include"Major_adc_defines.h"
#include"Major_adc.h"
#include "Major_fuel.h"
#include "delay.h"
#include "Major_lcd.h"
u32 adcDVal;
f32 eAR;
int main(void)
{
	int fuel;
	InitLCD();
	delay_us(100);
	//Init_ADC(1);

	while(1)
	{
	  //CmdLCD(0x01);
	  Read_ADC(CH1,&eAR,&adcDVal);
	  //fuel=((adcDVal/1023)*100);
	  fuel =(adcDVal*100)/1023;
	  CmdLCD(0x80);
	  CharLCD('f');
	  IntLCD(fuel);
	  CharLCD('%');
	  delay_ms(500);
	  //return fuel;  
	 }
}

