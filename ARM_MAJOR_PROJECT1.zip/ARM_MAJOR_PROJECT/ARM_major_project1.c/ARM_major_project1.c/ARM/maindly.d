maindly.o: maindly.c
maindly.o: delay.h
