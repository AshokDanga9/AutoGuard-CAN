/*Write an E.C.P. for displaying char ,int,

float and customized char on LCD*/

#include"lcd.h"

#include<LPC21xx.h>

#include"delay.h"

#include"macros.h"

int main()

{
	char add=0x80;
	InitLCD();//Initialization of 8-bit LCD
 	CmdLCD(0x80);//Cur is positioned at line 0 pos 0
	while(1)
	{
	while(add)
	{
	/*if(add>0x8f)
	{
	add=0xc0;
	}*/

	StrLCD("pears");
	CmdLCD(add);
	delay_ms(100);
	StrLCD("    ");
	//delay_ms(1000);
	add++;
	}
	}
	//while(1);

	//CmdLCD(0x48);//Cursor is placed at CGRAM loc
}	  
