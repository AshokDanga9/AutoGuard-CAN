ass3.o: ass3.c
ass3.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.h
ass3.o: macros.h
ass3.o: delay.h
ass3.o: rand.h
