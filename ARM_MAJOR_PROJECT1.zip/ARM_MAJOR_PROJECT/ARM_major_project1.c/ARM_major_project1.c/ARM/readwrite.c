#include<LPC21xx.h>
#include"pinconnectfunc.h"
#include"macros.h"
#define FN1 0
#define FN2 1
#define FN3 2
#define FN4 3
#define OUT 4
#define IN  5
int main()
{

		cfgPinFunc(0,IN,FN1);
		cfgPinFunc(0,OUT,FN1);

//P0.4 pin should be selected for GPIO func

		SETBIT(IODIR0,OUT);

	//IODIR0|=1<<4;

//P0.4 should be selected for output direction

	while(1)

	{

		if(((IOPIN0>>IN)&1)==0)

			IOCLR0=1<<OUT;

		else

			IOSET0=1<<OUT;

			

	}

 }