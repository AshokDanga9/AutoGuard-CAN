lpcxx.o: lpcxx.c
lpcxx.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.h
