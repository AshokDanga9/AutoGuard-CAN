#include <lpc21xx.h>
#include "types.h"
#include "delay.h"
#include "Major_adc.h"
#include "lcd.h"

u32 adcdval;
f32 voltage;

int main(void)
{
    InitLCD();
    initadc(0);              // P0.27 = AIN0

    while(1)
    {
        Read_ADC(0,&voltage,&adcdval);

        CmdLCD(0x01);
        CmdLCD(0x80);
        StrLCD("RAW ADC:");

        CmdLCD(0xC0);
        IntLCD(adcdval);

        delay_ms(500);
    }
}