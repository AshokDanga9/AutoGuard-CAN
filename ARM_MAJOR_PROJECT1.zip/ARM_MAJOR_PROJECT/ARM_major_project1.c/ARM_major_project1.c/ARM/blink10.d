blink10.o: blink10.c
blink10.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.h
blink10.o: macros.h
blink10.o: delay.h
