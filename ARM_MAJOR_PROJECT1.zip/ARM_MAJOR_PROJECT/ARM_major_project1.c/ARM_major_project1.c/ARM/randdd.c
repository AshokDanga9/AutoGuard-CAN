#include<LPC21xx.h>
//#include<stdio.h>
#include<time.h>
#include<stdlib.h>

int pand(int s)
{
 int i=5,sum=s,p;
 //srand(time(0));
 //for(i=0;i<6;i++)
 	while(--i)
 	{
		p=rand() %51;
		sum=sum+p;
  	}
	return sum;
}