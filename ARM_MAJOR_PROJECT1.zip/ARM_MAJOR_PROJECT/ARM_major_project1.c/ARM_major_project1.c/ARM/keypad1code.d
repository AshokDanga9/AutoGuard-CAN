keypad1code.o: Keypad1code.c
keypad1code.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.h
keypad1code.o: macros.h
keypad1code.o: Keypad_funcdef.h
keypad1code.o: types.h
keypad1code.o: LCD.h
keypad1code.o: types.h
