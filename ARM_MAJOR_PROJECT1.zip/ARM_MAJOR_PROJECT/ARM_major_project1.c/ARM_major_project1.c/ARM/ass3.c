#include<LPC21xx.h>
#include "macros.h"
#include "delay.h"
#include"rand.h"
#define SW 2
int main()
{
	int i,p,d;
	WRITEBYTE(IODIR0,8,0XFF);
	while(1)
	{
	if(((IOPIN0>>SW)&1)==0)
	{
		 p=pand(0);
		 d=high(p);
	 }
	 else{
	for(i=15;i<8;i++)
		 if(i<12)
		 {
		IOCLR0=d<<8;
		delay_ms(500);
		IOSET0=d<<8;
		delay_ms(500);
		}
		else
		{
		IOSET0=d<<8;
		delay_ms(500);
		IOCLR0=d<<8;
		delay_ms(500);
		}
		}
		}
		//while(1);
		}
