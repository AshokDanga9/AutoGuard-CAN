#include <LPC21XX.H>
#include "types.h"
#include "all_fun_decl.h"
#include "delay.h"
#include "macros.h"
int LLUT[][4]={{1,2,3,11},{4,5,6,22},{7,8,9,33},{0,44,88,77}};
char week[][4] = {"SUN","MON","TUE","WED","THU","FRI","SAT"};
int H,M,S,YY,DD,MM,k,d1,D;
//**********************************************************LCD Functions********************************************************************//
void CmdLCD(u8 cmd)																							//Command passing of LCD

{

        IOCLR0=1<<RS;//clear P0.8-->RS of LCD

        DispLCD(cmd);

}
																																//Displaying on LCD
void DispLCD(u8 val)

{

        IOCLR0=1<<RW;//clear P0.9--->RW of LCD^M

        WRITEBYTE(IOPIN0,0,val);//write cmd to P0.0-P0.7^M

        IOSET0=1<<EN;//make (P0.10)En high^M

        delay_ms(2);//min. of 450 nsec expected^M

        IOCLR0=1<<EN;//clear P0.10--->EN of LCD^M

        delay_ms(5);
}
																																		//Character display on LCD
void CharLCD(u8 dat)

{

        IOSET0=1<<RS;//SET P0.8-->RS of LCD

        DispLCD(dat);

}
//String Display on LCD
void StrLCD(u8 *ptr)

{

        while(*ptr!='\0')

                CharLCD(*ptr++);

}
//Integer Display on LCD
void IntLCD(s32 num)

{

        u8 a[10];

        s8 i=0;

        //itoa

        if(num==0)

                CharLCD('0');

        else

        {

                if(num<0)

                {

                        num=-num;

                        CharLCD('-');

                }

                while(num>0)

                {

                        a[i++]=num%10+48;

                        num=num/10;

                }
								
                for(--i;i>=0;i--)

                        CharLCD(a[i]);

        }
			}
																																				//Customised Character Display on LCD
void StoreCustCharFont(void)
{

        //u8 i,LUT[]={0x0e,0x0a,0x0e,0x00,0x00,0x00,0x00,0x00};
        u8 i;
        u32 LUT[]={0x18,0x18,0x03,0x04,0x04,0x03,0x00,0x00};

        for(i=0;i<8;i++)

                CharLCD(LUT[i]);
}
//*******************************************************************Key_pad Functions******************************************************//
s8 KeyVal(void)
 {
                u8 r_val=0,c_val=0;
        IOCLR0=1<<r0;
        IOSET0=((1<<r1)|(1<<r2)|(1<<r3));
        if((((IOPIN0>>c0)&0X0F) != 0X0F))
        {               r_val=0;
                goto col_check;
        }
        IOCLR0=1<<r1;
        IOSET0=((1<<r0)|(1<<r2)|(1<<r3));
         if((((IOPIN0>>c0)&0X0F) != 0X0F))
        {
                r_val=1;
                goto col_check;
        }
        IOCLR0=1<<r2;
        IOSET0=((1<<r0)|(1<<r1)|(1<<r3));
         if((((IOPIN0>>c0)&0X0F) != 0X0F))
        {
                r_val=2;
                goto col_check;
        }
        IOCLR0=1<<r3;
        IOSET0=((1<<r0)|(1<<r1)|(1<<r2));
        if((((IOPIN0>>c0)&0X0F) != 0X0F))
        {
                r_val=3;
                //goto col_check;
        }
col_check:
        if(((IOPIN0>>c0)&1) == 0)
        {
                c_val=0;
                                    c_val=0;
        }
        else if(((IOPIN0>>c1)&1)== 0)
        {
                c_val=1;
        }

        else if(((IOPIN0>>c2)&1) == 0)
        {
                c_val=2;
        }
        else
        {
                c_val=3;
        }
        IOCLR0=((1<<r0)|(1<<r1)|(1<<r2)|(1<<r3));
        return (LLUT[r_val][c_val]);
}
 
//***********************************************************RTC Functions************************************************************* //
/*
Get the current RTC time
hour Pointer to store the current hour
minute Pointer to store the current minute
second Pointer to store the current second
*/																																	
void GetRTCTimeInfo(s32 *hour, s32 *minute, s32 *second)
{
	*hour = HOUR;
	*minute = MIN;
	*second = SEC;
}
/*
Display the RTC time on LCD
hour value (0 23)
minute value (0 59)
second value (0 59) seperated by ':'																																					*/
void DisplayRTCTime(u32 hour, u32 minute, u32 second)
{
		CmdLCD(0x80);
		CharLCD((hour/10)+48);
		CharLCD((hour%10)+48);
		CharLCD(':');
		CharLCD((minute/10)+48);
		CharLCD((minute%10)+48);
		CharLCD(':');
		CharLCD((second/10)+48);
		CharLCD((second%10)+48);

}

/*
Get the current RTC date
day Pointer to store the current date (1 31)
month Pointer to store the current month (1 12)
year Pointer to store the current year (four digits)
*/
void GetRTCDateInfo(s32 *date, s32 *month, s32 *year)
{
	*date = DOM;
	*month = MONTH;
	*year = YEAR;
}
/*
Display the RTC date on LCD
Day of month (1 31)
Month (1 12)
Year (four digits) and seperated by '/'
*/
void DisplayRTCDate(u32 date, u32 month, u32 year)
{
		CmdLCD(0xC0);
		CharLCD((date/10)+48);
		CharLCD((date%10)+48);
		CharLCD('/');
		CharLCD((month/10)+48);
		CharLCD((month%10)+48);
		CharLCD('/');
		IntLCD(YEAR);
}

/*
Set the RTC time
Hour to set (0 23)
Minute to set (0 59)
Second to set (0 59)
*/
void SetRTCTimeInfo(u32 hour, u32 minute, u32 second)
{
	HOUR = hour;
	MIN = minute;
	SEC = second;
}

/*
Set the RTC date
day of month to set (1 31)
month to set (1 12)
year to set (four digits)
*/
void SetRTCDateInfo(u32 date, u32 month, u32 year)
{
	DOM = date;
	MONTH = month;
	YEAR = year;	
}

/*
Get the current day of the week
dow Pointer to store Day of Week (0=Sunday, ..., 6=Saturday)
*/
void GetRTCDay(s32 *day)
{
	*day = DOW; 
}

/*
Display the current day of the week on LCD
dow (Day of Week) (0=Sunday, ..., 6=Saturday)
*/
void DisplayRTCDay(u32 dow)
{
	CmdLCD(0x8A);
	StrLCD(week[dow]);  
}
/*
Set the day of the week in RTC
Day of Week to set (0=Sunday, ..., 6=Saturday)
*/
void SetRTCDay(u32 day)
{
	DOW = day;
}
//*****************************************************************ACD Function definition*******************************************************//
void Read_ADC(u32 chNo,f32 *eAR,u32 *adcDVal)
{
	//clear any previous channel selection
	ADCR&=0xFFFFFF00;
	//update req chNo,& start conv
	ADCR|=((1<<ADC_CONV_START_BIT)|(1<<chNo));
	//wait for conv time
	delay_us(3);
	//check if conv completed successfully
	while(((ADDR>>DONE_BIT)&1)==0);
	//stop adc conversion
	ADCR&=~(1<<ADC_CONV_START_BIT);
	//read digital data
	*adcDVal=((ADDR>>DIGITAL_DATA_BITS)&1023);
	
	*eAR=*adcDVal * (3.3/1023);
}
//****************************************************UART FUNCTION DEFINITION************************************************
s8 UARTRxChar(void)

{

		while(!READBIT(U0LSR,0));

		return (U0RBR);


}

void UARTTxChar(s8 ch)

{

	U0THR=ch;

	while(!READBIT(U0LSR,6));

}


void UARTTxStr(s8 *ptr)

{

	while(*ptr)
		UARTTxChar(*ptr++);
}


void UARTTxU32(u32 num)

{	

	u8 a[10];

	s8 i=0;

	//itoa

	if(num==0)
		UARTTxChar('0');

	else

	{

		while(num>0)

		{

			a[i++]=num%10+48;

			num=num/10;

		}

		for(--i;i>=0;i--)
			UARTTxChar(a[i]);

	}	

}


void UARTTxF32(f32 fnum)

{

	u32 num,i;

	if(fnum<0)

	{

		UARTTxChar('-');

		fnum=-fnum;

	}

	num=fnum;

	UARTTxU32(num);

	UARTTxChar('.');

	for(i=0;i<6;i++)

	{

		fnum=(fnum-num)*10;

		num=fnum;

		UARTTxChar(num+48);

	}

}
//************************************************EDIT MENU FUNCTIONS*****************************************************
void EDIT(void)
{
	while(1)
	{
while(((IOPIN0>>c0)&0X0F)==0X0F);                                                                                                 
k=KeyVal(); 
while(((IOPIN0>>c0)&0X0F)!=0X0F);                                                                          
				switch(k) 
						{
							case 1: 
											H=0;
										  d1=KeyVal();          
										  CmdLCD(0x80);
										  H=d1*10+KeyVal();                                                                                                                                                                        IntLCD(H);
						          break;
						 case 2:
											 M=0;
											 d1=KeyVal();
											 CmdLCD(0x80);
											 M=d1*10+KeyVal();
											 IntLCD(M);
											 break;
							case 3:
												S=0;
												d1=KeyVal();
												CmdLCD(0x80);
												S=d1*10+KeyVal();
												IntLCD(S);
												//return;
												break;
							case 4:
                       DD=0;
                       d1=KeyVal();
                       CmdLCD(0x80);
                       DD=d1*10+KeyVal();
                       IntLCD(DD);
                       break;
              case 5:
                        MM=0;
                        d1=KeyVal();
                        CmdLCD(0x80);
                        MM=d1*10+KeyVal();
                        IntLCD(MM);
                        break;
              case 6:
                        YY=0;
                        d1=KeyVal();
                        CmdLCD(0x80);
                        YY=d1*10+KeyVal();
                        IntLCD(YY);
                        break;
              case 7:
                         D=0;
                         d1=KeyVal();
                         CmdLCD(0x80);
                         D=KeyVal();
                         break;
							case 8:
                        return;
}
						}
/*int SETTEMP(void)
	{
    StrLCD("hello");
		return 0;
	}
int REPEAT(int a)
{
    u8 key;
    u32 num = 0;

    while(1)
    {
        while(!((IOPIN0>>c0)&0xff));

		delay_ms(10);
		key=KeyVal();

		while(((IOPIN0>>c0)&0xff));  // wait key release

        if(key >= '0' && key <= '9')
        {
            num = num*10 + (key-'0');
            CharLCD(key);
        }
        else if(key == '=')
        {
            return num;
        }
        else if(key == '*')
        {
            if(num > 0)
            {
                num /= 10;
                CmdLCD(0x10);
                CharLCD(' ');
                CmdLCD(0x10);
            }
        }
    }
}*/
}