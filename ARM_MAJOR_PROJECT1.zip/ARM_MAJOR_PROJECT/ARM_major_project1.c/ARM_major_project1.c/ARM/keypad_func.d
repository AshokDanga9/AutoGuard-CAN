keypad_func.o: Keypad_func.c
keypad_func.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.h
keypad_func.o: Keypad_fun_define.h
keypad_func.o: types.h
keypad_func.o: lut.h
keypad_func.o: LCD.h
keypad_func.o: types.h
