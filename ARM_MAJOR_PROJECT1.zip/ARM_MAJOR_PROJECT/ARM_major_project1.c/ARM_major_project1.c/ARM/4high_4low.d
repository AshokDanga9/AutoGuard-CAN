4high_4low.o: 4high_4low.c
4high_4low.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.h
4high_4low.o: macros.h
4high_4low.o: ispalindrome.h
4high_4low.o: delay.h
