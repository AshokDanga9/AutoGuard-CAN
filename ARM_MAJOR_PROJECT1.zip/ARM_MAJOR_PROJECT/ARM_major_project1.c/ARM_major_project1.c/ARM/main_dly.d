main_dly.o: main_dly.c
main_dly.o: delay.h
