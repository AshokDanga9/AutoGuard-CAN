//can_rx_test.c
#include <LPC21xx.H>
#include "Major_Can.h"
#include "types.h"
#include "delay.h"
#define LED_VAL 0xff

CANF rxF;

void left_indicator()
{
	int i;
	for(i=0;i<8;i++)
	{
		IOSET0=(1<<i);
		delay_ms(200);
		IOCLR0=(1<<i);
	}
}


void right_indicator()
{
	int j;

	for(j=7;j>=0;j--)
	{
		IOSET0=(1<<j);
		delay_ms(200);
		IOCLR0=(1<<j);
	}
} 

int main(void)
{
						                                           
	IODIR0|=(LED_VAL<<0);
	//IOCLR0=(LED_VAL<<0);
	//IODIR0|=(1<<0)|(1<<1);
	
	Init_CAN1();
	//CAN1_Rx(&rxF);
	while(1)
	{
		if(C1GSR&(1<<0))
		{
			CAN1_Rx(&rxF);
	  
	  		if (rxF.ID==1)
			{
				if(rxF.Data1==0x01)
				{
					left_indicator();
				}
				else if(rxF.Data1==0x02)
				{
					right_indicator();
				}
				else if(rxF.Data1==0X00)
				{
					IOCLR0=(LED_VAL<<0);
				}
						
			}
			C1CMR|=(1<<2);
		 }

		 }
}



