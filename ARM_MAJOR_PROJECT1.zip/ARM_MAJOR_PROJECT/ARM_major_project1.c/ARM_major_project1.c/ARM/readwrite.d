readwrite.o: readwrite.c
readwrite.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.h
readwrite.o: pinconnectfunc.h
readwrite.o: macros.h
