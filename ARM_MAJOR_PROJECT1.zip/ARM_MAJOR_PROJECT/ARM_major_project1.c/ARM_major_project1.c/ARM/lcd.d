lcd.o: LCD.c
lcd.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.h
lcd.o: delay.h
lcd.o: LCD.h
lcd.o: types.h
lcd.o: types.h
lcd.o: macros.h
