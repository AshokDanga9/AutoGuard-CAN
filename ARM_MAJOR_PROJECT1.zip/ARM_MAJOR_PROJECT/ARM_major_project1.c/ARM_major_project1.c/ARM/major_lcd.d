major_lcd.o: Major_lcd.c
major_lcd.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.h
major_lcd.o: delay.h
major_lcd.o: LCD.h
major_lcd.o: types.h
major_lcd.o: types.h
major_lcd.o: macros.h
