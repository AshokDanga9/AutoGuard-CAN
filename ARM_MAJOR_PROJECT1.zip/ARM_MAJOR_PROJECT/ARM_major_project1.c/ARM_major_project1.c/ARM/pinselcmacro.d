pinselcmacro.o: pinselcmacro.c
pinselcmacro.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.h
pinselcmacro.o: PinConnectfunc.h
pinselcmacro.o: macros.h
