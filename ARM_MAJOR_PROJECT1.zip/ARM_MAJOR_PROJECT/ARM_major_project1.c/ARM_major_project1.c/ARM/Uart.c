#include<LPC21xx.h>
#include"macros.h"
#include"PinConnectFunc.h"
#include"types.h"
void InitUART(void)
{
	//PINSEL0|=0x00000001;
	//CfgPinFunc(0,0,1);//P0.0 for TXD0
	cfgPinFunc(0,1,1);//P0.1 for RXD0

	U0LCR=0x03;//8-bit wordlength with1 stop bit
	U0LCR|=1<<7;//DLAB=1
	U0DLL=97;
	U0DLM=0;
	U0LCR&=~(1<<7);//DLAB=0
	
}
s8 UARTRxChar(void)
{
		while(!READBIT(U0LSR,0));
		return (U0RBR);

}
void UARTTxChar(s8 ch)
{
	U0THR=ch;
	while(!READBIT(U0LSR,6));
}

void UARTTxStr(s8 *ptr)
{
	while(*ptr)
		UARTTxChar(*ptr++);
	
}