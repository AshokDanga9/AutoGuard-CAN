#include<LPC21xx.h>
#include"pinconnectfunc.h"
#define FN1 0
#define FN2 1
#define FN3 2
#define FN4 3
int main()
{
	cfgPinFunc(0,17,FN3);//here function call is made instead of whole process
	//cfgPinFunc(1,21,FN2);

	//PINSEL0=((PINSEL0&~(3<<18))|(2<<18));

	//P0.9 with fn3(PWM) 

	PINSEL1=((PINSEL1&~(3<<8))|(3<<8));//P0.20 with fn4(EINT)

	while(1);

}
