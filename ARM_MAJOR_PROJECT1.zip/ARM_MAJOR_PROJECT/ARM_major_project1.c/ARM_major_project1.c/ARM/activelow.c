#include<LPC21xx.h>
#include"macros.h"
#include"delay.h"
int main()
		  {
	int i;
	WRITEBYTE(IODIR0,0,0XFF);
	while(1)
	{
		//for(i=0;i<8;i++)
		for(i=7;i>=0;i--)
		{
		if(((IOPIN0>>i)&1)==0)
			IOCLR0=1<<i;
			else{
			//IOCLR0=1<<i;
			//delay_ms(400);
			IOSET0=1<<i;
		}
		}
	}
	}
