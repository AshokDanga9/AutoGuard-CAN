major_can.o: Major_Can.c
major_can.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.h
major_can.o: types.h
major_can.o: delay.h
major_can.o: Major_candefines.h
major_can.o: Major_can.h
major_can.o: types.h
