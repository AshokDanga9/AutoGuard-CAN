sample_adc.o: sample_adc.c
sample_adc.o: types.h
sample_adc.o: delay.h
sample_adc.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.h
sample_adc.o: Major_adc_defines.h
