ispalindrome.o: ispalindrome.c
ispalindrome.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.h
