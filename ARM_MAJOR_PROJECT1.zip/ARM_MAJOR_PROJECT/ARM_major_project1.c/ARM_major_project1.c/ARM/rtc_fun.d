rtc_fun.o: rtc_fun.c
rtc_fun.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.H
rtc_fun.o: rtc_defines.h
rtc_fun.o: types.h
rtc_fun.o: lcd.h
rtc_fun.o: types.h
