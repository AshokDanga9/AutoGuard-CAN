rand.o: rand.c
rand.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.h
rand.o: C:\KeilARM\ARM\RV31\INC\stdio.h
rand.o: C:\KeilARM\ARM\RV31\INC\time.h
rand.o: C:\KeilARM\ARM\RV31\INC\stdlib.h
