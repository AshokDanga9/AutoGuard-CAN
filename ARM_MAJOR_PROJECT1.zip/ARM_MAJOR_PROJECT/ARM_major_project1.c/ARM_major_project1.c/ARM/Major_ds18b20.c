//DS18B20 TEMPRATURE SENSOR
#include <LPC22xx.H>
#include"delay.h"
#include"types.h"
#include"Major_dsb18b20.h"
//#define DP  15
#define Dat 1<<15
#define Rdst (IOPIN0&(1<<15)) // Read_status
u8 ResetDs18b20(void)

{
unsigned int presence;
IODIR0 |=Dat;
//IOPIN0 |=Dat;
IOSET0=Dat;
delay_us(1);
//IOPIN0 &=~(Dat);
IOCLR0=Dat;
delay_us(486);
//IOPIN0 |=Dat;
IOSET0=Dat;
delay_us(55);
presence=IOPIN0;
//presence=IOPIN0 & Dat;
delay_us(431);
if(presence&Rdst)
 //flag=1;
//if (!presence) // siri
 return 1;
 else
 return 0;
 }
 u8 ReadBit(void)
 {
 	unsigned int Bit;
	IODIR0 |=Dat;
	//IPIN0 &=~(Dat);
	IOCLR0=Dat;
	delay_us(3);
	//IOPIN0 |= Dat;
	//IOSET0=Dat; now change
	IODIR0 &=~(Dat);
	delay_us(11);
	Bit=(IOPIN0&Dat)?1:0;
	delay_us(53);
	return Bit;
	//IODIR0 |= Dat;
	//if(Bit & Rdst)
	/*if(Bit & Dat)
	{
		return 1;
	}
 	else
	{
		return 0;
	} */

 }
 void WriteBit(u8 Databit)
 {
 	//IOPIN0 &=~(Dat);
	IOCLR0=Dat;
	delay_us(1);
	if(Databit)
		//IOPIN0|=Dat;
		IOSET0=Dat;
	delay_us(59);
	//IOPIN0 |= Dat;
	IOSET0=Dat;
	delay_us(1);
  }
 u8 ReadByte(void)
  {
  	unsigned char i;
	unsigned char DatIn=0;
	for(i=0;i<8;i++)
	{
		//DatIn |=ReadBit()?0x01<<i:DatIn	;
		if(ReadBit())
		  DatIn|=(1<<i);
		delay_us(46);	
	}
  	return (DatIn);
  }
void WriteByte(u8 DatOut)
{
	u8 i;
	for(i=0;i<8;i++)
	{
		WriteBit((DatOut&0x1));
		DatOut=DatOut>>1;
		delay_us(1);
	}
	delay_us(100);
}
int ReadTemp(void)
{
	u8 n,buff[2];
	int temp;
	float temperature;	
	ResetDs18b20();
	WriteByte(0xcc);
	WriteByte(0x44);
	//delay_ms(800);
	//while(!ReadBit());
	while(ReadByte()==0xff);
	ResetDs18b20();
	WriteByte(0xcc);
	WriteByte(0xBE);
	for(n=0;n<2;n++)
	{
		buff[n]=ReadByte();
	}
	temp=buff[1];
	temp=temp<<8;
	temp=temp|buff[0];
	temperature = temp;  // siri
	return (temperature);			  // siri
}
