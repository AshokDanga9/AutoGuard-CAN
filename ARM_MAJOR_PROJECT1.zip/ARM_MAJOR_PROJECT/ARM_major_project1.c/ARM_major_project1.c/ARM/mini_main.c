#include <lpc214x.h>
#include "all_fun_decl.h"
#define SW 15
s32 hour,min,sec,date,month,year,day;

// Main function
int main()
{
	int key;
  // Initialize RTC 
	RTC_Init();
		
  // Initialize the LCD
	InitLCD();
	//Initialize the KeyPad
	keypadInt();
	//Initialize the ADC
	Init_ADC(CH0);
	Init_ADC(CH1);
  //Initilization of UART
	InitUART();
	// Set the initial time (hours, minutes, seconds)
	SetRTCTimeInfo(12,14,00);
	SetRTCDateInfo(30,10,2025);
	SetRTCDay(4);


  while (1) 
	{
    // Get and display the current time on LCD
		GetRTCTimeInfo(&hour,&min,&sec);
		DisplayRTCTime(hour,min,sec);
		GetRTCDateInfo(&date,&month,&year);
		DisplayRTCDate(date,month,year);
		GetRTCDay(&day);
		DisplayRTCDay(day);
		 while(1)
        {
        if(((IOPIN0>>SW)&1)==0)
        {
           while(((IOPIN0>>SW)&1)==0);  // wait for release

                while(1)   // MENU LOOP
                 {
                 CmdLCD(0x01);
                  CmdLCD(0x80);
                  StrLCD("1:editinfo 2:edittemp");
                  CmdLCD(0xc0);
                  StrLCD("3:exit");
									 while(((IOPIN0>>c0)&0X0F)==0X0F);                                                                                                 
										key=KeyVal(); 
										while(((IOPIN0>>c0)&0X0F)!=0X0F); 
                 // key = KeyVal();   // read keypad key
									 switch(key)
									 {
										 case 1: EDIT();
															break;
										 case 2: StrLCD("hello");
															break;//SETTEMP();
										 case 3: StrLCD("exiting");
															return;
									 }
             }
    }
				return;
	}
}
				}