#include<LPC21XX.h>
#include"types.h"
#include"Major_adc_defines.h"
#include"Major_adc.h"
#include "Major_fuel.h"
#include "delay.h"
#include "Major_Can.h"
#include "Major_candefines.h"
#include "Major_lcd.h"

f32 aR1;
u32 adcdval;
u8 fuel;

f32 voltage;
f32 fuel_value;

CANF txF;

int main(void)
{
    //InitLCD();
    Init_CAN1();
    initadc(1);

    txF.ID=2;
    txF.BFV.RTR=0;
    txF.BFV.DLC=4;

    while(1)
    {
        //CmdLCD(0x01);

        Read_ADC(1,&voltage,&adcdval);

        /*
           Fuel sensor calibration:
           0.05V  = 0%
           0.32V  = 100%
        */
        fuel_value=((voltage-0.05)/0.27)*100.0;

        if(fuel_value <= 0.0)
        {
            fuel=0;
        }
        else if(fuel_value >= 100.0)
        {
            fuel=100;
        }
        else
        {
            fuel=(u8)fuel_value;
        }

        txF.Data1=fuel;

        CAN1_Tx(txF);

        delay_ms(100);
    }
}