#include"types.h"
void keypadInt(void);
s8 KeyVal(void);
void edit(void);
//u8 COLCHECK(void);
#define r0 16
#define r1 17
#define r2 18
#define r3 19
#define c0 20
#define c1 21
#define c2 22
#define c3 23
#define SW 24
