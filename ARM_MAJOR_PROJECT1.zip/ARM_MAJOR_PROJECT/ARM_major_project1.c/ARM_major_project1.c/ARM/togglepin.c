#include<LPC21xx.h>
#include"pinconnectfunc.h"
#include"macros.h"
#include"delay.h"
#define FN1 0
#define FN2 1
#define FN3 2
#define FN4 3
int main()
{
cfgPinFunc(0,4,FN1);
SETBIT(IODIR0,4);
while(1)
{
	//if(((IOPIN0>>4)&1)==0)
			IOCLR0=1<<4;
	//else	 
			delay_ms(500);
	        IOSET0=1<<4;
 b			delay_ms(500);
}
}
	    

	

