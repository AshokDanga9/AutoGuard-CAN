activelow.o: activelow.c
activelow.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.h
activelow.o: macros.h
activelow.o: delay.h
