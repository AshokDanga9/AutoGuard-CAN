mini_main.o: mini_main.c
mini_main.o: C:\KeilARM\ARM\INC\Philips\lpc214x.h
mini_main.o: all_fun_decl.h
mini_main.o: types.h
mini_main.o: types.h
