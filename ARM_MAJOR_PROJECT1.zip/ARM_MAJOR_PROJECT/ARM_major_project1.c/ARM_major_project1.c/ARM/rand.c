#include<LPC21xx.h>
#include<stdio.h>
#include<time.h>
#include<stdlib.h>

int pand(int s)
{
 int i,arr[6],sum=0;
 //int i,sum=s,p;
 //srand(time(0));
 for(i=0;i<6;i++)
 	{
		/*input:p=rand() %1000;
		   if(p<1000)
		   {
		   		--i;
				goto input;
				} */
input:  arr[i]=rand() % 9999 ;
        if(arr[i]<1000)
        {
                --i;
                goto input;
        }
        sum=sum+arr[i];
		//sum=sum+p;
  	}
	//high(sum);
	return sum;
}



