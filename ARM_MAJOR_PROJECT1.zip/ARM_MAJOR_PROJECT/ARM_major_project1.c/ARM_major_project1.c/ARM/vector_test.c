/*Write an E.C.P. for displaying char ,int,

float and customized char on LCD*/

#include"lcd.h"

#include<LPC21xx.h>

#include"delay.h"

#include"macros.h"

int main()

{
	char add;
	InitLCD();//Initialization of 8-bit LCD
 	CmdLCD(0x80);//Cur is positioned at line 0 pos 0
	for(add=0x80;add<0x8f;add++)
	{
	//CmdLCD(add);
	StrLCD("pears");
	/*CmdLCD(add);
	StrLCD(" "); */
	delay_ms(1000);
	}
	while(1);
	//CmdLCD(0x48);//Cursor is placed at CGRAM loc
}	  
