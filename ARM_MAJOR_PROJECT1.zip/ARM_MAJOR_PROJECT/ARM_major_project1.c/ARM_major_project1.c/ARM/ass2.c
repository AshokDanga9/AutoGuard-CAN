/*Write an ECP to display below mentioned patterns on 8-led�s (4-active high led�s and
4-active low led�s)
a. Turn ON one by one led from left to right at the rate of 1 second
b. Turn ON one by one led from right to left at the rate of 1 second*/
#include<LPC21xx.h>
#include"delay.h"
#include"macros.h"
int main()
{
	int i;
		WRITEBYTE(IODIR0,8,0XFF);
		WRITENIBBLE(IOSET0,8,0X0F);
			for(i=15;i>=12;i--)
				{
						IOSET0=1<<i;
						delay_ms(500);
						IOCLR0=1<<i;
						delay_ms(500);
				}

			for(i=11;i>=8;i--)
			{
            WRITENIBBLE(IOSET0,8,0X0F);
						if(((IOSET0>>i)&1)==0)
						{
								IOSET0=(1<<i);
								delay_ms(500);
								IOCLR0=1<<i;
								delay_ms(500);
					  }
						else{
								IOCLR0=1<<i;
								delay_ms(500);
								IOSET0=(1<<i);
								delay_ms(500);
			}		                   }                                                                                                                                                                                                                             
				while(1);
}
			 	/*IOSET0=(1<<i)^(0x0f00);
						delay_ms(500);
						IOCLR0=1<<i;
						delay_ms(500);*/