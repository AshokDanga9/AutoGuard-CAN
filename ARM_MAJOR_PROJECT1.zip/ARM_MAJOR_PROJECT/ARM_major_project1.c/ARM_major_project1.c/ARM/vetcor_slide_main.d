vetcor_slide_main.o: vetcor_slide_main.c
vetcor_slide_main.o: lcd.h
vetcor_slide_main.o: types.h
vetcor_slide_main.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.h
vetcor_slide_main.o: delay.h
vetcor_slide_main.o: macros.h
