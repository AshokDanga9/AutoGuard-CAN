led.o: led.c
led.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.h
led.o: delay.h
led.o: pinconnectfunc.h
led.o: macros.h
