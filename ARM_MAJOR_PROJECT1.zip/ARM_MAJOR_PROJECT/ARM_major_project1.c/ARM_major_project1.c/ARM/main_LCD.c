/*Write an E.C.P. for displaying char ,int,

float and customized char on LCD*/

#include"lcd.h"

#include<LPC21xx.h>

#include"delay.h"

#include"macros.h"

int main()

{

	InitLCD();//Initialization of 8-bit LCD
 while(1){
//	CmdLCD(0x84);//Cur is positioned at line 0 pos 0

	//CharLCD('');//Disp ASCII A char 	
	CmdLCD(0x01);
	delay_ms(100);
	CmdLCD(0x80);//Cur is positioned at line 0 pos 0
	StrLCD("HELLO PEARS");
//	CmdLCD(0x8f);
	CharLCD('!');//Disp ASCII A char 

//	CmdLCD(0xc0);

//	IntLCD(2107);
	/*CmdLCD(0x94);
	StrLCD("Hi");
	CmdLCD(0xa2);
	StrLCD("HELLO"); */

	//CmdLCD(0xc8);

	//FltLCD(21.15);

//	CmdLCD(0x48);//Cursor is placed at CGRAM loc


/*StoreCustCharFont();

	CmdLCD(0xCF);//2nd Line last pos

	CharLCD(1);//font is read from 8*1+0x40 loc
  */
	

	

	//while(1);
		  }
}	  
