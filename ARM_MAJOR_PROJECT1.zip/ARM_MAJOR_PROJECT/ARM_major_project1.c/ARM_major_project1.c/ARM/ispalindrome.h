int ispalindrome(int);
