#include <lpc214x.h>
/*#define H 0
#define M 0 
#define S 0
#define DD 0
#define MM 0
#define YY 0
#define D  0*/
#include "rtc.h"
#include "keypad_fun_define.h"
#include "types.h"
#include "LCD.h"

s32 hour,min,sec,date,month,year,day;
int H=1,M=12,S=25,DD=21,MM=11,YY=25,D=2,deg=23,d1,key; //here intialisation of keypad variables


// Main function

int main()

{

  // Initialize RTC 

	RTC_Init();

		

  // Initialize the LCD

	InitLCD();

	// Initialize the KEYPAD


  // Set the initial time (hours, minutes, seconds)

	SetRTCTimeInfo(H,M,S);

	SetRTCDateInfo(DD,MM,YY);

	SetRTCDay(D);

	//LUT[]={0x00,0x00,0x04,0x0c,0x1c,0x1c,0x1c,0x00};


 while(1)
        {
        if(((IOPIN0>>SW)&1)==0)
        {
           while(((IOPIN0>>SW)&1)==0);   // wait for release

                while(1)   // MENU LOOP
                 {
                 CmdLCD(0x01);
                  CmdLCD(0x80);
                  //Disp_menu();

                  key = KeyVal();   // read keypad key

                  if(key == '1')
                  {
                  //edit();    // stays here until user exits edit screen
                   }
                                if(key=='2')
                                {
                                         //set_point=setpoint();


                                }
               if(key == '8')   // EXIT MENU
               {
               CmdLCD(0x01);
               StrLCD("EXITING");
            //delay_ms(300);
			   break;           // <-- leaves menu loop
             }
    }
}


                GetRTCTimeInfo(&hour,&min,&sec);
                DisplayRTCTime(hour,min,sec);


                GetRTCDateInfo(&date,&month,&year);
                DisplayRTCDate(date,month,year);
                GetRTCDay(&day);
                DisplayRTCDay(day);


                              

    // Get and display the current time on LCD
		GetRTCTimeInfo(&hour,&min,&sec);
		DisplayRTCTime(hour,min,sec);
		GetRTCDateInfo(&date,&month,&year);
		DisplayRTCDate(date,month,year);
		GetRTCDay(&day);
		DisplayRTCDay(day);
		CmdLCD(0xc9);
		CharLCD('T');
		CmdLCD(0xcA);
		CharLCD(':');
		CmdLCD(0xcB);
		IntLCD(23);
		CmdLCD(0x48);//Cursor is placed at CGRAM loc
		StoreCustCharFont();
		CmdLCD(0xCF);//2nd Line last pos
		CharLCD(1);//
			
 }}
