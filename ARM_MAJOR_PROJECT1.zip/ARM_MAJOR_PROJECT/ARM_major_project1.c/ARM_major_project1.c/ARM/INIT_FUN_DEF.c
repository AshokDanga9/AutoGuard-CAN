#include <LPC21XX.H>
#include "macros.h"
#include "delay.h"
#include "all_fun_decl.h"
#include "types.h"
u32 adcChSel[4]={AIN0_PIN_0_27,
                 AIN1_PIN_0_28,
                 AIN2_PIN_0_29,
                 AIN3_PIN_0_30
                };

// ********************************************LCD RELATED FILES********************************************************************** //
//Initilization of LCD
void InitLCD(void)

{

        //P0.0-P0.10--By default GPIO pins

        IODIR0|=((LCD_DAT<<0)|(1<<RS)|(1<<RW)|(1<<EN));

                 //0x7ff

        //P0.0-P0.10 pis are sel for ouput dir

        delay_ms(20);//min 15 msec required

        CmdLCD(0x30);//8-bit mode enabling

        delay_ms(10);//min. of 5 msec
				 CmdLCD(0x30);//8-bit mode enabling

        delay_ms(1);//min. of 160 usec

        CmdLCD(0x30);//8-bit mode enabling

        delay_ms(1);//min. of 160 usec

        CmdLCD(0x38);//8-bit with 5*7 font 1 lines disp

        CmdLCD(0x10);//Display off

        CmdLCD(0x01);//Clear display

        CmdLCD(0x06);//Set cursor move direction

        CmdLCD(0x0f);//Disp ON ,cursor ON with Blinking

}
//Command passing of LCD


//******************************************************Keypad Initilization*******************************************************************//
void keypadInt(void)     // Intilization of keypad!
{
        IODIR0|=((1<<r0)|(1<<r1)|(1<<r2)|(1<<r3));  // setting to o/p direction
        IOCLR0=((1<<r0)|(1<<r1)|(1<<r2)|(1<<r3));         // intially rows should be zeros
}



//*******************************************************RTC Initilization******************************************************************//
/*
Initialize the Real-Time Clock (RTC)
This function disables the RTC, sets the prescaler values, 
and then enables the RTC.
*/
void RTC_Init(void) 
{
  // Disable and reset the RTC
	CCR = RTC_RESET;
  
#ifdef _LPC2148
  // Enable the RTC & select the clock source
	CCR = RTC_ENABLE | RTC_CLKSRC;  
#else
  // Set prescaler integer and fractional parts
	PREINT = PREINT_VAL;
	PREFRAC= PREFRAC_VAL;
  
  // Enable the RTC
	CCR = RTC_ENABLE;  
	
#endif

}
//********************************************************************ADC Intilization*******************************************************//
void Init_ADC(u32 chNo)
{
	//clear prev cfgs of p0.27-p0.30
	PINSEL1&=~(adcChSel[chNo]);
	//cfg req p0.27-p0.30 as AIN0-AIN3 pins
	PINSEL1|=adcChSel[chNo];
	//cfg ADCR
	ADCR|=(1<<PDN_BIT)|(CLKDIV<<CLKDIV_BITS);
}
//***************************************************UART INTIALISATION****************************************************8
void InitUART(void)

{

	PINSEL0|=0x00000001;

	//CfgPinFunc(0,0,1);//P0.0 for TXD0

	//CfgPinFunc(0,1,1);//P0.1 for RXD0


	U0LCR=0x03;//8-bit wordlength with1 stop bit

	U0LCR|=1<<7;//DLAB=1

	U0DLL=97;

	U0DLM=0;

	U0LCR&=~(1<<7);//DLAB=0

	

}












