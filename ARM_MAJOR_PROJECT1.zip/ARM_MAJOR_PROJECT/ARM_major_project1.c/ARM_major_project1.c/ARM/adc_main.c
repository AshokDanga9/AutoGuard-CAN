//adc_lm35_uart_test.c

#include <LPC21xx.h>

#include "types.h"

#include "Major_adc.h"

#include "Major_adc_defines.h"

#include "delay.h"

#include "uart.h"

//#include "lm35.h"
int adcvalue;
float voltage;
int In;

main()

{

	//Init_ADC(AIN0_PIN_0_27|AIN1_PIN_0_28);

	//Init_ADC(CH0);

	Init_ADC(CH1);

	//InitUART();
	InitLCD();

	//UARTTxStr("LM35 TEST: \n\r");

	delay_ms(1000);

	while(1)

	{

		//UARTTxStr("Temperature : ");
		Read_ADC(CH1,&voltage,&adcvalue);
		In=(adcvalue*100)/1023;
		IntLCD(In);
		StrLCD("hello");
		CmdLCD(0xc0);
		FltLCD(voltage);
		delay_s(5);
		CmdLCD(0x01);

		//UARTTxF32(Read_LM35_NP('C'));

		//UARTTxStr(" deg C \n\r"); 

	}

}