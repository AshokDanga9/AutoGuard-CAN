#include<LPC21xx.h>
#include"delay.h"
#include"pinconnectfunc.h"
#include"macros.h"
#define FN1 0
#define FN2 1
#define FN3 2
#define FN4 3
int main()
{

cfgPinFunc(0,7,FN1);
cfgPinFunc(0,5,FN1);
SETBIT(IODIR0,5);
SETBIT(IODIR0,7);
while(1)
{
	IOPIN0^=(1<<7);
	delay_ms(500);
	}
	}
