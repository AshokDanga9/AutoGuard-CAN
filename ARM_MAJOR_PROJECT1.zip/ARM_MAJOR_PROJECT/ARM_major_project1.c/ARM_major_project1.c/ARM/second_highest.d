second_highest.o: second_highest.c
second_highest.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.h
