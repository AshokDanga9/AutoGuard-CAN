#include<LPC21xx.h>
#include"macros.h"
#include"Keypad_funcdef.h"
#include"LCD.h"
/*#define R0 15
#define R1 16
#define R2 17
#define R3 18
#define C0 19
#define C1 20
#define C2 21
#define C3 22*/
//first initialise the lcd for display.
int main()
{
InitLCD();

	CmdLCD(0x80);

	//IntLCD(123);
Keyint();		  // to initialise the row and col
//colcheck();      //to check the status of col's
while(1)
{
	while(colcheck());//for staying till the switch is release
		delay_ms(10);//for avoiding keybouncing time.

  		CmdLCD(0x84);

		CharLCD(Keyval());

		while(!(colcheck()));

		//wait for sw release

	}
}


