#include <LPC21xx.h>
#include "delay.h"
#include "Major_can.h"
#include "types.h"
#include "Major_lcd.h"
#include "pinconnectfunc.h"


#define OFF   0
#define LEFT  1
#define RIGHT 2


volatile u8 indicator_status = OFF;

volatile u8 left_flag = 0;
volatile u8 right_flag = 0;

CANF txF;


void sendsignal(void);
void eint0_isr(void) __irq;
void eint1_isr(void) __irq;


int main(void)
{

    Init_CAN1();

    // LCD initialization

    InitLCD();

    CmdLCD(0x80);
    StrLCD(" <<< DASH BOARD >>> ");

    CmdLCD(0xC0);
    StrLCD("Indicator ");

    /* Initial indicator display */

    CmdLCD(0xC0 + 13);
    CharLCD(5);              // <

    CmdLCD(0xC0 + 15);
    CharLCD(6);              // >


    /* EINT CONFIGURATION */

    CfgPinFunc(0,1,3);       // P0.1  -> EINT0
    CfgPinFunc(0,14,2);      // P0.14 -> EINT1

    /* Edge triggered interrupt */
    EXTMODE |= (1 << 0) | (1 << 1);

    /* Falling edge */
    EXTPOLAR &= ~((1 << 0) | (1 << 1));

    /* Clear pending interrupts */
    EXTINT = (1 << 0) | (1 << 1);


    /*  VIC configuration  */

    /* EINT0 = interrupt number 14 */
    VICVectCntl0 = (1 << 5) | 14;
    VICVectAddr0 = (u32)eint0_isr;

    /* EINT1 = interrupt number 15 */
    VICVectCntl1 = (1 << 5) | 15;
    VICVectAddr1 = (u32)eint1_isr;

    /* Enable EINT0 and EINT1 */
    VICIntEnable = (1 << 14) | (1 << 15);


    /* MAIN LOOP */

    while(1)
    {


        if(left_flag)
        {
            left_flag = 0;

            /*
             * If LEFT is already ON:
             *      LEFT -> OFF
             *
             * Otherwise:
             *      OFF/RIGHT -> LEFT
             */

            indicator_status =
                (indicator_status == LEFT) ? OFF : LEFT;

            sendsignal();
        }


        /* RIGHT BUTTON EVENT */

        if(right_flag)
        {
            right_flag = 0;

            /*
             * If RIGHT is already ON:
             *      RIGHT -> OFF
             *
             * Otherwise:
             *      OFF/LEFT -> RIGHT
             */

            indicator_status =
                (indicator_status == RIGHT) ? OFF : RIGHT;

            sendsignal();
        }


        /* LEFT INDICATOR */

        if(indicator_status == LEFT)
        {
            CmdLCD(0xC0 + 13);
            CharLCD(5);              // <

            delay_ms(300);

            CmdLCD(0xC0 + 13);
            CharLCD(' ');

            CmdLCD(0xC0 + 15);
            CharLCD(6);              // > steady
        }


        /* RIGHT INDICATOR */

        else if(indicator_status == RIGHT)
        {
            CmdLCD(0xC0 + 13);
            CharLCD(5);              // < steady

            CmdLCD(0xC0 + 15);
            CharLCD(6);              // >

            delay_ms(300);

            CmdLCD(0xC0 + 15);
            CharLCD(' ');
        }


        /* OFF STATE */

        else
        {
            CmdLCD(0xC0 + 13);
            CharLCD(5);

            CmdLCD(0xC0 + 15);
            CharLCD(6);
        }

        delay_ms(100);
    }
}


/* EINT0 : LEFT BUTTON */

void eint0_isr(void) __irq
{
    

    left_flag = 1;

    /* Clear EINT0 interrupt */
    EXTINT = (1 << 0);

    /* End of ISR */
    VICVectAddr = 0;
}


/* EINT1 : RIGHT BUTTON */

void eint1_isr(void) __irq
{
    right_flag = 1;

    /* Clear EINT1 interrupt */
    EXTINT = (1 << 1);

    /* End of ISR */
    VICVectAddr = 0;
}


/* CAN TRANSMISSION */

void sendsignal(void)
{
    txF.ID = 0x11;

    txF.BFV.RTR = 0;
    txF.BFV.DLC = 1;

    if(indicator_status == LEFT)
    {
        txF.Data1 = 'L';
    }
    else if(indicator_status == RIGHT)
    {
        txF.Data1 = 'R';
    }
    else
    {
        txF.Data1 = 'O';
    }

    CAN1_Tx(txF);
}
