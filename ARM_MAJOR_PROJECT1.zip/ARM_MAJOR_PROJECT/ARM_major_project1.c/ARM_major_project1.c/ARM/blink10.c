#include<LPC21xx.h>
#include"macros.h"
#include"delay.h"
int main()
{
		//int i=10,cnt=0;
		SETBIT(IODIR0,8);//BIT 8 SET FOR OUTPUT DIRECTION.
		//while(i--)
			while(1)
			{
				//cnt++;
				IOSET0=1<<8;
				delay_ms(100);
				IOCLR0=1<<8;
				delay_ms(100);
			}
			//while(1);
			}


