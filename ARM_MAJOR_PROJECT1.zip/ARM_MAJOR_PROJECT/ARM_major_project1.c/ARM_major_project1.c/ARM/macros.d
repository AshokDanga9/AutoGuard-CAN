macros.o: macros.c
