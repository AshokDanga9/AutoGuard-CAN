init_fun_def.o: INIT_FUN_DEF.c
init_fun_def.o: C:\KeilARM\ARM\INC\Philips\LPC21XX.H
init_fun_def.o: macros.h
init_fun_def.o: delay.h
init_fun_def.o: all_fun_decl.h
init_fun_def.o: types.h
init_fun_def.o: types.h
init_fun_def.o: types.h
