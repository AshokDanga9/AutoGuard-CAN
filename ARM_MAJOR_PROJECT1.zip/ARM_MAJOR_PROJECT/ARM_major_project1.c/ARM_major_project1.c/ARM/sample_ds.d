sample_ds.o: sample_ds.c
sample_ds.o: C:\KeilARM\ARM\INC\Philips\LPC22xx.H
sample_ds.o: delay.h
sample_ds.o: types.h
sample_ds.o: Major_dsb18b20.h
