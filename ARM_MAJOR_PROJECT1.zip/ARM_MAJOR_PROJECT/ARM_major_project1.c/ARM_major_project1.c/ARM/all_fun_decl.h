#include "types.h"

//***************************************************LCD Function Declarations****************************************************************//

void InitLCD(void);

void CmdLCD(u8 cmd);

void DispLCD(u8 val);

void CharLCD(u8 dat);

void StrLCD(u8 *ptr);

void IntLCD(s32 num);

void StoreCustCharFont(void);

//****************************************************LCD defines**********************************************************//

#define LCD_DAT 2//data lines --P0.0-P0.7

#define RS 13 //P0.8

#define RW 12 //P0.9

#define EN 14 //P0.10

//****************************************************Key_pad Function Declarations**************************************************//

void keypadInt(void);

s8 KeyVal(void);

//****************************************************Key_pad defines**************************************************************//

#define r0 16

#define r1 17

#define r2 18

#define r3 19

#define c0 20

#define c1 21

#define c2 22

#define c3 23

//**************************************************RTC MACRO DEFINES**************************************************************** //

#ifndef RTC_DEFINES_H

#define RTC_DEFINES_H


// System clock and peripheral clock Macros

#define FOSC 12000000

#define CCLK (5*FOSC)    

#define PCLK (CCLK/4) 


// RTC Macros

#define PREINT_VAL ((PCLK/32768)-1)

#define PREFRAC_VAL (PCLK-(PREINT_VAL+1)*32768)


//CCR register bits 

#define RTC_ENABLE  (1<<0)

#define RTC_RESET   (1<<1)

#define RTC_CLKSRC  (1<<4)


//#define _LPC2148




#endif

//*****************************************************RTC FUNCTION DECLARATION****************************************************//

#ifndef RTC_H

#define RTC_H


#include "types.h"


void RTC_Init(void);

void GetRTCTimeInfo(s32 *,s32 *,s32 *);

void DisplayRTCTime(u32,u32,u32);

void GetRTCDateInfo(s32 *,s32 *,s32 *);

void DisplayRTCDate(u32,u32,u32);


void SetRTCTimeInfo(u32,u32,u32);

void SetRTCDateInfo(u32,u32,u32);


void GetRTCDay(s32 *);

void DisplayRTCDay(u32);

void SetRTCDay(u32);

#endif

//*******************************************************ADC Function Declarations***************************************************//

void Init_ADC(u32 chNo);

void Read_ADC(u32 chNo,f32 *eAR,u32 *adcDVal);

//*******************************************************ADC Defines****************************************************************//

#define FOSC 12000000

#define CCLK (FOSC*5)

#define PCLK (CCLK/4)

#define ADCCLK 3000000

#define CLKDIV ((PCLK/ADCCLK)-1)


//defines for ADCR sfr

#define CLKDIV_BITS        8 //@8-15

#define PDN_BIT            21

#define ADC_CONV_START_BIT 24


//defines for ADDR sfr

#define DIGITAL_DATA_BITS 6//@6-15

#define DONE_BIT          31


#define AIN0_PIN_0_27 0x00400000

#define AIN1_PIN_0_28 0x01000000

#define AIN2_PIN_0_29 0x04000000

#define AIN3_PIN_0_30 0x10000000


#define CH0 0

#define CH1 1

#define CH2 2

#define CH3 3

//add mores defines as & when required

//***********************************************UART FUNCTIONS*********************************************************

void InitUART(void);

void UARTTxChar(s8);

void UARTTxStr(s8 *);

s8 UARTRxChar(void);

void UARTTxU32(u32);

void UARTTxF32(f32);

void UartTx_RTC_Time(u32,u32,u32);

void UartTx_RTC_date(u32,u32,u32);

//************************************************EDIT MENU******************************************************************

void EDIT(void);

int REPEAT(int);

int SETTEMP(void);