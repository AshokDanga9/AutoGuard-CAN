randdd.o: randdd.c
randdd.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.h
randdd.o: C:\KeilARM\ARM\RV31\INC\time.h
randdd.o: C:\KeilARM\ARM\RV31\INC\stdlib.h
