keypad_fun_def.o: keypad_fun_def.c
keypad_fun_def.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.H
keypad_fun_def.o: keypad_fun_define.h
keypad_fun_def.o: types.h
keypad_fun_def.o: lut.h
