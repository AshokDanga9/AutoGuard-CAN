major_ds18b20.o: Major_ds18b20.c
major_ds18b20.o: C:\KeilARM\ARM\INC\Philips\LPC22xx.H
major_ds18b20.o: delay.h
major_ds18b20.o: types.h
major_ds18b20.o: Major_dsb18b20.h
